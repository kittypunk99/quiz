<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>500 Internal Server Error</title>
</head>
<body>
<h1>500 Internal Server Error</h1>
<p>Something went wrong. Please try again later.</p>
</body>
</html>